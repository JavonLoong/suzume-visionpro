import RealityKit
import Foundation

/// 虚拟门框 + 门扇（遮挡兜底方案，对应技术方案第 5 节方案 1）。
///
/// 为什么需要它：RealityKit 的 PortalComponent 不处理「真实物体（passthrough 中的人/门扇）
/// 遮挡虚拟世界」。在实机验证遮挡方案之前，先用与实体门框同尺寸的「虚拟门框 + 门扇」
/// 放在门户前，让门扇正常遮挡门后世界，保证前后关系可信。
///
/// 之后若用 SceneReconstruction 或 OcclusionMaterial 做真实遮挡，可整体停用本装配。
enum DoorOcclusion {

    static func makeDoorAssembly() -> Entity {
        let door = Entity()
        door.name = "DoorAssembly"

        door.addChild(makeDoorFrame())
        door.addChild(makeDoorLeaf())

        // 门扇初始为关闭（遮住门洞），可改角度实现开合
        return door
    }

    // MARK: - 门框（与实体门框同尺寸，用于视觉与遮挡对齐）

    private static func makeDoorFrame() -> Entity {
        let frame = Entity()
        frame.name = "DoorFrame"

        let wood = PhysicallyBasedMaterial()
        var mat = wood
        mat.baseColor = .init(tint: .init(white: 0.82, alpha: 1.0))
        mat.roughness = 0.9

        let w = PortalConfig.doorWidth
        let h = PortalConfig.doorHeight
        let t = PortalConfig.doorThickness

        // 左右立柱
        for side in [-1, 1] {
            let post = ModelEntity(
                mesh: .generateBox(width: t, height: h, depth: t),
                materials: [mat]
            )
            post.position = [Float(side) * (w / 2 + t / 2), h / 2, 0]
            frame.addChild(post)
        }
        // 上梁
        let header = ModelEntity(
            mesh: .generateBox(width: w + 2 * t, height: t, depth: t),
            materials: [mat]
        )
        header.position = [0, h + t / 2, 0]
        frame.addChild(header)

        return frame
    }

    // MARK: - 门扇（关闭时遮挡门后世界）

    private static func makeDoorLeaf() -> Entity {
        let w = PortalConfig.doorWidth
        let h = PortalConfig.doorHeight
        let t = PortalConfig.doorThickness * 0.5

        var mat = PhysicallyBasedMaterial()
        mat.baseColor = .init(tint: .init(white: 0.78, alpha: 1.0))
        mat.roughness = 0.85

        let leaf = ModelEntity(
            mesh: .generateBox(width: w, height: h, depth: t),
            materials: [mat]
        )
        leaf.name = "DoorLeaf"
        // 放在门洞前方（朝体验者一侧），略微前移，正常遮挡 portal 内世界
        leaf.position = [0, h / 2, -t / 2 - 0.02]

        // 铰链在左侧，绕左立柱旋转可实现开门；先保持关闭姿态
        // 开合动画：把 leaf 绕 Y 轴旋转 0 → -100° 即可（需求里门扇活动为待确认项）
        return leaf
    }
}
