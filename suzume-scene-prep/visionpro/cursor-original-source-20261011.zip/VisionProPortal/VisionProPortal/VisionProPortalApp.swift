import SwiftUI

/// 铃芽之旅 · 梦幻门（visionOS 门户体验）
/// 戴 Vision Pro 看实体白门，透过门洞看到门后的梦幻世界。
@main
struct VisionProPortalApp: App {
    var body: some Scene {
        // 主窗口：进入/退出沉浸空间的入口
        WindowGroup {
            ContentView()
        }
        .windowStyle(.volumetric)
        .defaultSize(width: 0.8, height: 0.6, depth: 0.4, in: .meters)

        // 混合沉浸空间：passthrough（现实）+ 虚拟门后世界
        ImmersiveSpace(id: "suzumePortalSpace") {
            PortalImmersiveView()
        }
        .immersionStyle(selection: .constant(.mixed), in: .mixed)
    }
}
