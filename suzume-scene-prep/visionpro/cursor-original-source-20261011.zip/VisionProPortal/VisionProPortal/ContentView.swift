import SwiftUI

/// 主窗口：控制沉浸空间的进入/退出，并展示当前状态。
struct ContentView: View {
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @State private var isInSpace = false

    var body: some View {
        VStack(spacing: 24) {
            Text("铃芽之旅 · 梦幻门")
                .font(.title)

            Text("戴上 Vision Pro，透过门洞看门后的世界。")
                .font(.callout)
                .foregroundStyle(.secondary)

            if !isInSpace {
                Button {
                    Task {
                        await openImmersiveSpace(id: "suzumePortalSpace")
                        isInSpace = true
                    }
                } label: {
                    Label("进入梦幻门", systemImage: "door.left.hand.open")
                        .font(.headline)
                }
            } else {
                Button {
                    Task {
                        await dismissImmersiveSpace()
                        isInSpace = false
                    }
                } label: {
                    Label("退出", systemImage: "door.left.hand.closed")
                        .font(.headline)
                }
            }
        }
        .padding(40)
    }
}
