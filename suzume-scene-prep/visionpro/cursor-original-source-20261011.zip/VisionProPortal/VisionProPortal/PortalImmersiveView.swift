import SwiftUI
import RealityKit

/// 沉浸空间视图：挂载门户场景。
struct PortalImmersiveView: View {
    @State private var portalSystem = PortalSystem()

    var body: some View {
        RealityView { content in
            portalSystem.setup()
            if let root = portalSystem.rootEntity {
                content.add(root)
            }
        }
        .onDisappear {
            portalSystem.teardown()
        }
    }
}
