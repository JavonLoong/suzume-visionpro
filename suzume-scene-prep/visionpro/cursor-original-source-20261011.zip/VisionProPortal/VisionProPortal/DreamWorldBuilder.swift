import RealityKit
import Foundation

/// 门后梦幻世界（portal 的 target）：星空、水面、花海、柔和的光。
/// 先用程序化几何跑通，之后可整体替换为从 `.blend` 导出的 USDZ 资产（见 USDZ导出流程.md）。
enum DreamWorldBuilder {

    static func build() -> Entity {
        let world = Entity()
        world.name = "DreamWorld"

        if PortalConfig.enableStars {
            world.addChild(makeStarField())
        }
        if PortalConfig.enableWater {
            world.addChild(makeWater())
        }
        if PortalConfig.enableFlowerField {
            world.addChild(makeFlowerField())
        }
        world.addChild(makeAmbientLight())

        return world
    }

    // MARK: - 星空（粒子式小球，散布在门后上方）

    private static func makeStarField() -> Entity {
        let stars = Entity()
        stars.name = "Stars"

        var rng = SystemRandomNumberGenerator()
        let starCount = 400

        for _ in 0..<starCount {
            let star = ModelEntity(
                mesh: .generateSphere(radius: 0.008),
                materials: [UnlitMaterial(color: .white)]
            )
            // 随机分布在一个朝向门后的半球/盒空间里
            let x = Float.random(in: -3...3, using: &rng)
            let y = Float.random(in: 0.5...4, using: &rng)
            let z = Float.random(in: -6...(-2), using: &rng)
            star.position = [x, y, z]
            // 随机大小
            star.scale = .init(repeating: Float.random(in: 0.5...1.5, using: &rng))
            stars.addChild(star)
        }
        return stars
    }

    // MARK: - 水面（半透明平面，带轻微蓝绿）

    private static func makeWater() -> Entity {
        let water = ModelEntity(
            mesh: .generatePlane(width: 8, depth: 8),
            materials: [makeWaterMaterial()]
        )
        water.name = "Water"
        water.position = [0, 0.02, -3]   // 门后地面略下，形成水面
        water.orientation = simd_quatf(angle: -.pi / 2, axis: [1, 0, 0]) // 躺平
        return water
    }

    private static func makeWaterMaterial() -> PhysicallyBasedMaterial {
        var mat = PhysicallyBasedMaterial()
        mat.baseColor = .init(tint: .init(red: 0.35, green: 0.6, blue: 0.7))
        mat.roughness = 0.1
        mat.blending = .transparent(opacity: 0.7)
        return mat
    }

    // MARK: - 花海（简化为彩色地面片）

    private static func makeFlowerField() -> Entity {
        let field = Entity()
        field.name = "FlowerField"

        var rng = SystemRandomNumberGenerator()
        let patchCount = 120
        for _ in 0..<patchCount {
            let color: UIColor = [.systemPink, .systemPurple, .systemTeal, .systemOrange]
                .randomElement(using: &rng)!
            let patch = ModelEntity(
                mesh: .generatePlane(width: 0.15, depth: 0.15),
                materials: [UnlitMaterial(color: color)]
            )
            patch.position = [
                Float.random(in: -4...4, using: &rng),
                0.05,
                Float.random(in: -5...(-2.5), using: &rng)
            ]
            patch.orientation = simd_quatf(angle: -.pi / 2, axis: [1, 0, 0])
            field.addChild(patch)
        }
        return field
    }

    // MARK: - 环境光

    private static func makeAmbientLight() -> Entity {
        let light = Entity()
        let point = PointLightComponent(color: .white, intensity: 1500)
        light.components.set(point)
        light.position = [0, 3, -3]
        return light
    }
}
