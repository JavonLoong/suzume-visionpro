import Foundation
import simd

/// 铃芽之旅门户体验的全局可调参数。
/// 关键点：所有与实体门框对齐相关的数值都集中在这里，
/// 实机校准时只改这一个文件即可，不用动逻辑代码。
enum PortalConfig {
    // MARK: - 门洞净开口（沿用建模占位值，实机按实体门实测调整）

    /// 门洞净宽（米）
    static let doorWidth: Float = 1.0
    /// 门洞净高（米）
    static let doorHeight: Float = 2.1
    /// 门框厚度（米），用于遮挡兜底门扇与对齐基准
    static let doorThickness: Float = 0.12

    // MARK: - 门在现实空间中的放置（实机校准项）

    /// 门洞中心的世界坐标（米）。实机用 WorldAnchor 或手动拖到实体门框处后覆盖。
    static let portalPosition = SIMD3<Float>(0, 0, 0)
    /// 门朝向（弧度，绕 Y 轴）。0 = 门面朝 -Z（朝体验者）。
    static let portalRotationY: Float = 0
    /// 整体缩放（园林整体缩放时，portal 与梦幻世界同步缩放）。
    static let worldScale: Float = 1.0

    // MARK: - 梦幻世界（门后场景）

    /// 门后世界是否含星空粒子
    static let enableStars = true
    /// 门后世界是否含水面
    static let enableWater = true
    /// 门后世界是否含花海（简化为彩色地面片）
    static let enableFlowerField = true

    // MARK: - 音频

    /// 是否启用门后世界空间音频（风声/水流/虫鸣）
    static let enableSpatialAudio = false
}
