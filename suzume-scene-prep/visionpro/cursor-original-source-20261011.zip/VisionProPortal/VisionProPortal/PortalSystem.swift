import RealityKit
import Foundation

/// 门户场景的组装器：把「门后梦幻世界 + 门户 + 门框门扇」拼成一棵实体树。
///
/// 核心机制（RealityKit PortalComponent）：
/// - `portal` 实体带一个 plane mesh，其边界就是「门洞开口」。
/// - 给 `portal` 设置 `PortalComponent(target: dreamWorld)` 后，
///   RealityKit 只在开口范围内渲染 `dreamWorld`，开口外保持现实（passthrough），
///   并自带正确的头部视差与遮挡。这正是需求里「门洞内显示另一空间」的实现基础。
@MainActor
final class PortalSystem {
    var rootEntity: Entity?
    private var dreamWorld: Entity?

    func setup() {
        let root = Entity()
        root.name = "SuzumePortalRoot"

        // 1. 门后梦幻世界（作为 portal 的 target）
        let world = DreamWorldBuilder.build()
        world.name = "DreamWorld"
        self.dreamWorld = world

        // 2. 门户实体：开口 = 门洞净开口尺寸
        let portal = makePortal(target: world)

        // 3. 门框 + 门扇（虚拟兜底，用于遮挡门后世界、保证前后关系）
        let door = DoorOcclusion.makeDoorAssembly()

        // 树的层级：world 是 portal 的 target（不挂到 root 的可见层），
        // portal 和 door 挂在 root 下。door 在 portal 前，正常遮挡 portal 内世界。
        root.addChild(portal)
        root.addChild(door)

        // 4. 应用对齐参数（位置/朝向/缩放），实机校准只改 PortalConfig
        applyAlignment(root: root)

        // 5. 空间音频（可选，按需打开）
        if PortalConfig.enableSpatialAudio {
            attachSpatialAudio(to: world)
        }

        rootEntity = root
    }

    func teardown() {
        rootEntity = nil
        dreamWorld = nil
    }

    // MARK: - Portal

    private func makePortal(target: Entity) -> Entity {
        let portal = Entity()
        portal.name = "SuzumePortal"

        // 门洞开口：一个 plane，尺寸用门洞净开口（实机按实体门实测覆盖）
        let mesh = MeshResource.generatePlane(
            width: PortalConfig.doorWidth,
            height: PortalConfig.doorHeight
        )
        // portal 实体的 mesh 只定义「开口形状」，材质本身会被 portal 效果替换
        let model = ModelComponent(mesh: mesh, materials: [UnlitMaterial()])
        portal.components.set(model)

        // 关键：把门户指向门后世界
        let portalComponent = PortalComponent(target: target)
        portal.components.set(portalComponent)

        return portal
    }

    // MARK: - Alignment

    private func applyAlignment(root: Entity) {
        // 位置、朝向、缩放统一施加在 root 上，保证 portal 与梦幻世界同步缩放
        root.position = PortalConfig.portalPosition
        root.orientation = simd_quatf(angle: PortalConfig.portalRotationY, axis: [0, 1, 0])
        root.scale = SIMD3<Float>(repeating: PortalConfig.worldScale)

        // 实机校准时，先把 portal 的四个角对齐实体门框四角，
        // 再逐步调 PortalConfig.portalPosition / portalRotationY / worldScale。
    }

    // MARK: - Spatial Audio

    private func attachSpatialAudio(to world: Entity) {
        // 示例：门后世界的风声。真实音频文件需放入 Resources 并替换文件名。
        if let audio = try? AudioFileResource.load(
            named: "dreamworld_ambience",
            in: nil,
            configuration: .init(shouldLoop: true)
        ) {
            world.spatialAudio = SpatialAudioComponent()
            world.playAudio(audio)
        }
    }
}
